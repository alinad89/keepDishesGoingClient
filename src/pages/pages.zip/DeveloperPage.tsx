import { Link } from 'react-router-dom'
import Card from '../components/Card'
import Section from '../components/Section'
import './DeveloperPage.css'

function DeveloperPage() {
  const integrationSteps = [
    {
      icon: '📝',
      title: 'Register Your Game',
      description: 'Fill out the game registration form with basic information including name, description, genre, and game assets. Your game will be reviewed and approved within 24 hours.'
    },
    {
      icon: '🏆',
      title: 'Define Achievements',
      description: 'Create and register achievements for your game. Each achievement includes a name, description, icon, and unlock criteria. The platform will track player progress automatically.'
    },
    {
      icon: '📨',
      title: 'Integrate Message Queue',
      description: 'Set up async messaging to communicate with the Hexagon platform. All events (player actions, achievements, lobby updates) are handled via event-driven architecture for maximum reliability.'
    },
    {
      icon: '🧪',
      title: 'Test Integration',
      description: 'Use our sandbox environment to test your game integration. Verify that achievements unlock correctly, lobby matchmaking works, and all events are properly sent/received via the message queue.'
    },
    {
      icon: '🚀',
      title: 'Deploy & Launch',
      description: 'Once testing is complete, deploy your game to production. Your game will appear in the Hexagon catalog and be available to all players on the platform.'
    }
  ]

  return (
    <div className="developer-page">
      <Section
        title="Add Your Game to Hexagon"
        subtitle="Easy integration for game developers. Connect your game to our platform using async messaging."
        centered
      >
        <div className="developer-content">
          {/* Hero Section */}
          <div className="developer-hero">
            <h3>🎮 Developer-Friendly Integration</h3>
            <p>
              Hexagon makes it incredibly easy to add your game to our platform.
              With event-driven architecture and async messaging, your game integrates seamlessly without complex dependencies.
            </p>
          </div>

          {/* Integration Steps */}
          <div className="integration-steps">
            <h3>Integration Process</h3>
            <div className="steps-grid">
              {integrationSteps.map((step, index) => (
                <div key={index} className="step-card">
                  <div className="step-number">{index + 1}</div>
                  <Card
                    icon={step.icon}
                    title={step.title}
                    description={step.description}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Technical Details */}
          <div className="technical-section">
            <h3>📡 Async Messaging Architecture</h3>
            <div className="code-section">
              <h4>Event Types</h4>
              <div className="code-block">
                <pre>{`// Game Events (sent by your game)
{
  "type": "ACHIEVEMENT_UNLOCKED",
  "gameId": "your-game-id",
  "playerId": "player-123",
  "achievementId": "first-win",
  "timestamp": "2025-01-22T10:30:00Z"
}

{
  "type": "PLAYER_JOINED",
  "gameId": "your-game-id",
  "playerId": "player-123",
  "lobbyId": "lobby-456"
}

{
  "type": "GAME_COMPLETED",
  "gameId": "your-game-id",
  "playerId": "player-123",
  "stats": {
    "score": 1500,
    "duration": 300
  }
}`}</pre>
              </div>

              <h4>Platform Events (received by your game)</h4>
              <div className="code-block">
                <pre>{`// Lobby Events
{
  "type": "LOBBY_READY",
  "lobbyId": "lobby-456",
  "players": ["player-123", "player-456"],
  "gameId": "your-game-id"
}

{
  "type": "FRIEND_INVITE",
  "fromPlayerId": "player-789",
  "toPlayerId": "player-123",
  "gameId": "your-game-id"
}`}</pre>
              </div>

              <h4>Achievement Registration</h4>
              <div className="code-block">
                <pre>{`// Register achievements for your game
{
  "gameId": "your-game-id",
  "achievements": [
    {
      "id": "first-win",
      "name": "First Victory",
      "description": "Win your first game",
      "icon": "🏆",
      "category": "progression"
    },
    {
      "id": "speed-demon",
      "name": "Speed Demon",
      "description": "Complete a level in under 60 seconds",
      "icon": "⚡",
      "category": "challenge"
    }
  ]
}`}</pre>
              </div>
            </div>
          </div>

          {/* Connection Details */}
          <div className="connection-section">
            <h3>🔌 Connection Details</h3>
            <div className="info-cards">
              <div className="info-card">
                <h4>Message Queue</h4>
                <p><strong>Protocol:</strong> AMQP / RabbitMQ</p>
                <p><strong>Endpoint:</strong> <code>mq.hexagon.platform/games</code></p>
                <p><strong>Auth:</strong> API Key (provided after registration)</p>
              </div>
              <div className="info-card">
                <h4>REST API (Optional)</h4>
                <p><strong>Base URL:</strong> <code>api.hexagon.platform/v1</code></p>
                <p><strong>Docs:</strong> <a href="#">View API Documentation</a></p>
                <p><strong>Auth:</strong> Bearer Token (OAuth 2.0)</p>
              </div>
              <div className="info-card">
                <h4>WebSocket (Real-time)</h4>
                <p><strong>Endpoint:</strong> <code>wss://ws.hexagon.platform</code></p>
                <p><strong>Use Case:</strong> Live lobby updates, real-time matchmaking</p>
                <p><strong>Auth:</strong> Token-based authentication</p>
              </div>
            </div>
          </div>

          {/* Benefits */}
          <div className="benefits-section">
            <h3>✨ Why Integrate with Hexagon?</h3>
            <div className="benefits-grid">
              <div className="benefit-item">
                <span className="benefit-icon">👥</span>
                <h4>Access to Players</h4>
                <p>Reach thousands of active players looking for new games</p>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">🎯</span>
                <h4>Smart Matchmaking</h4>
                <p>Built-in lobby system handles player matching for you</p>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">🏆</span>
                <h4>Achievement System</h4>
                <p>Ready-made achievement tracking and display</p>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">📊</span>
                <h4>Analytics Dashboard</h4>
                <p>Track player engagement and game performance</p>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">💰</span>
                <h4>Monetization Support</h4>
                <p>Optional integration with payment providers</p>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">🔧</span>
                <h4>Easy Maintenance</h4>
                <p>Event-driven architecture means minimal coupling</p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="developer-cta">
            <h3>Ready to Get Started?</h3>
            <p>Access the developer dashboard to register your game and manage your integrations.</p>
            <div className="cta-actions">
              <Link to="/developer/dashboard">
                <button className="btn btn-primary">
                  <span style={{ marginRight: '0.5rem' }}>🚀</span>
                  Open Developer Dashboard
                </button>
              </Link>
              <button className="btn btn-outline">View Full Documentation</button>
            </div>
          </div>
        </div>
      </Section>
    </div>
  )
}

export default DeveloperPage
