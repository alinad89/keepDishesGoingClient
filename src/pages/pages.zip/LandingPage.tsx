import { Link } from 'react-router-dom'
import Button from '../components/Button'
import Card from '../components/Card'
import Section from '../components/Section'
import './LandingPage.css'

function LandingPage() {
  const features = [
    {
      icon: '🎮',
      title: 'Find Games & Favourites',
      description: 'Browse an extensive catalog of games. Search, filter, and mark your favourites. Discover new experiences or revisit classics with ease.'
    },
    {
      icon: '🎯',
      title: 'Smart Lobby & Matchmaking',
      description: 'Join lobbies to get matched with players. Once enough players are ready, start the game. Fast, fair, and seamless matchmaking powered by async messaging.'
    },
    {
      icon: '👥',
      title: 'Friends & Stats',
      description: 'Search for other players and add them as friends. Invite friends to play together or compare your stats and achievements.'
    },
    {
      icon: '🏆',
      title: 'Achievements & Progress',
      description: 'Track your achievements across all games. See which achievements you\'ve unlocked, which are still locked, and how to unlock them.'
    },
    {
      icon: '🛠️',
      title: 'For Game Developers',
      description: 'Easy integration for external game developers. Register your game, define achievements, and communicate via async message queue (event-driven architecture).'
    },
    {
      icon: '🤖',
      title: 'AI Assistant - Coming Soon',
      description: 'Intelligent chatbot to help you find games, get recommendations, and answer questions about the platform. Powered by Data & AI.'
    }
  ]

  return (
    <div className="landing-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Hexagon: One Platform, Endless Games</h1>
          <p className="hero-subtitle">
            Your ultimate gaming hub featuring smart matchmaking lobbies, friends system,
            achievement tracking, and seamless game integration via async message queues.
            Join thousands of players and developers building the future of gaming.
          </p>
          <div className="hero-buttons">
            <Link to="/games">
              <Button variant="primary">Browse Games</Button>
            </Link>
            <Link to="/developer">
              <Button variant="outline">Add Your Game</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <Section
        title="Everything You Need"
        subtitle="Hexagon combines powerful features for players and developers in one seamless platform"
        centered
      >
        <div className="features-grid">
          {features.map((feature, index) => (
            <Card
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-card">
          <h3 className="cta-title">Ready to Get Started?</h3>
          <p className="cta-description">
            Join Hexagon today and experience the future of gaming platforms.
            Whether you're a player or a developer, we've got you covered.
          </p>
          <div className="cta-buttons">
            <Link to="/games">
              <Button variant="primary">Explore Games</Button>
            </Link>
            <Link to="/lobby">
              <Button variant="secondary">Join a Lobby</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default LandingPage
